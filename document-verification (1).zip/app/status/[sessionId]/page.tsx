"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Shield, ArrowLeft, AlertCircle } from "lucide-react"
import Link from "next/link"
import { StatusTracker } from "@/components/status-tracker"
import {
  getVerificationSession,
  updateVerificationStep,
  completeVerificationSession,
  type VerificationSession,
} from "@/lib/status-tracker"

export default function StatusPage() {
  const params = useParams()
  const router = useRouter()
  const sessionId = params.sessionId as string
  const [session, setSession] = useState<VerificationSession | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (sessionId) {
      const foundSession = getVerificationSession(sessionId)
      setSession(foundSession)
      setIsLoading(false)

      // Simulate real-time updates for demo
      if (foundSession && foundSession.overallStatus === "processing") {
        const interval = setInterval(() => {
          simulateProgress(sessionId)
          const updatedSession = getVerificationSession(sessionId)
          setSession(updatedSession)

          if (updatedSession?.overallStatus === "completed" || updatedSession?.overallStatus === "failed") {
            clearInterval(interval)
          }
        }, 3000)

        return () => clearInterval(interval)
      }
    }
  }, [sessionId])

  const simulateProgress = (sessionId: string) => {
    const session = getVerificationSession(sessionId)
    if (!session) return

    const currentStep = session.steps.find((s) => s.status === "in-progress")
    if (currentStep) {
      // Randomly complete current step
      if (Math.random() > 0.3) {
        updateVerificationStep(
          sessionId,
          currentStep.id,
          "completed",
          `${currentStep.name} completed successfully`,
          0.85 + Math.random() * 0.1,
        )

        // Check if this was the last step
        const updatedSession = getVerificationSession(sessionId)
        if (updatedSession && updatedSession.currentStep === "completed") {
          completeVerificationSession(sessionId, "HASH_" + Math.random().toString(36).substr(2, 9).toUpperCase())
        }
      }
    }
  }

  const handleRefresh = () => {
    const updatedSession = getVerificationSession(sessionId)
    setSession(updatedSession)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-6 text-center">
            <p>Loading verification status...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Session Not Found</CardTitle>
            <CardDescription>The verification session could not be found</CardDescription>
          </CardHeader>
          <CardContent>
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Session ID "{sessionId}" does not exist or has expired. Please start a new verification.
              </AlertDescription>
            </Alert>
            <div className="mt-4">
              <Link href="/upload">
                <Button className="w-full">Start New Verification</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold text-foreground">Verification Status</h1>
                <p className="text-sm text-muted-foreground">Real-time tracking of your document verification</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <StatusTracker session={session} onRefresh={handleRefresh} />
        </div>
      </main>
    </div>
  )
}
