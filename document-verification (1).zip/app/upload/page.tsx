"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, FileText, Shield, ArrowLeft, AlertCircle } from "lucide-react"
import Link from "next/link"
import { createVerificationSession } from "@/lib/status-tracker"

export default function UploadPage() {
  const router = useRouter()
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [documentType, setDocumentType] = useState<string>("")
  const [consentGiven, setConsentGiven] = useState(false)
  const [dragActive, setDragActive] = useState(false)
  const [uploadStatus, setUploadStatus] = useState<"idle" | "uploading" | "success" | "error">("idle")
  const [errorMessage, setErrorMessage] = useState("")

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelection(e.dataTransfer.files[0])
    }
  }, [])

  const handleFileSelection = (file: File) => {
    // Validate file type
    const allowedTypes = ["image/jpeg", "image/jpg", "image/png", "application/pdf"]
    if (!allowedTypes.includes(file.type)) {
      setErrorMessage("Please upload a valid image (JPEG, PNG) or PDF file")
      return
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      setErrorMessage("File size must be less than 10MB")
      return
    }

    setSelectedFile(file)
    setErrorMessage("")
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelection(e.target.files[0])
    }
  }

  const handleUpload = async () => {
    if (!selectedFile || !documentType || !consentGiven) {
      setErrorMessage("Please complete all required fields and give consent")
      return
    }

    setUploadStatus("uploading")
    setErrorMessage("")

    try {
      // Simulate upload process
      await new Promise((resolve) => setTimeout(resolve, 2000))

      const session = createVerificationSession(documentType as "pan" | "aadhaar" | "certificate", selectedFile.name)
      if (typeof window !== "undefined") {
        sessionStorage.setItem("sessionId", session.sessionId)
      }
      router.push(
        `/process?type=${documentType}&fileName=${encodeURIComponent(selectedFile.name)}&sessionId=${session.sessionId}`,
      )
    } catch (error) {
      setUploadStatus("error")
      setErrorMessage("Upload failed. Please try again.")
    }
  }

  const resetForm = () => {
    setSelectedFile(null)
    setDocumentType("")
    setConsentGiven(false)
    setUploadStatus("idle")
    setErrorMessage("")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold text-foreground">Document Upload</h1>
                <p className="text-sm text-muted-foreground">Secure document verification</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Document Type Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Select Document Type</CardTitle>
              <CardDescription>Choose the type of document you want to verify</CardDescription>
            </CardHeader>
            <CardContent>
              <Select value={documentType} onValueChange={setDocumentType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select document type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pan">PAN Card</SelectItem>
                  <SelectItem value="aadhaar">Aadhaar Card</SelectItem>
                  <SelectItem value="certificate">Certificate</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {/* File Upload */}
          <Card>
            <CardHeader>
              <CardTitle>Upload Document</CardTitle>
              <CardDescription>
                Drag and drop your document or click to browse. Supported formats: JPEG, PNG, PDF (max 10MB)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  dragActive
                    ? "border-primary bg-primary/5"
                    : selectedFile
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/50"
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                {selectedFile ? (
                  <div className="space-y-4">
                    <FileText className="h-12 w-12 text-primary mx-auto" />
                    <div>
                      <p className="font-medium text-foreground">{selectedFile.name}</p>
                      <p className="text-sm text-muted-foreground">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                    <Button variant="outline" onClick={() => setSelectedFile(null)}>
                      Remove File
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <Upload className="h-12 w-12 text-muted-foreground mx-auto" />
                    <div>
                      <p className="text-lg font-medium text-foreground">Drop your document here</p>
                      <p className="text-muted-foreground">or click to browse files</p>
                    </div>
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={handleFileInput}
                      className="hidden"
                      id="file-upload"
                    />
                    <Label htmlFor="file-upload">
                      <Button variant="outline" asChild>
                        <span>Browse Files</span>
                      </Button>
                    </Label>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Consent */}
          <Card>
            <CardHeader>
              <CardTitle>Privacy Consent</CardTitle>
              <CardDescription>Please review and accept our privacy terms</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-muted rounded-lg text-sm text-muted-foreground">
                <p className="mb-2 font-medium text-foreground">Data Usage Agreement:</p>
                <ul className="space-y-1 list-disc list-inside">
                  <li>Your document will be processed locally using AI for verification</li>
                  <li>No document data will be stored on external servers</li>
                  <li>Biometric data is processed locally and not transmitted</li>
                  <li>Only verification results and hash IDs are stored</li>
                  <li>You can request data deletion at any time</li>
                </ul>
              </div>

              <div className="flex items-start space-x-2">
                <Checkbox
                  id="consent"
                  checked={consentGiven}
                  onCheckedChange={(checked) => setConsentGiven(checked as boolean)}
                />
                <Label htmlFor="consent" className="text-sm leading-relaxed">
                  I consent to the processing of my document and biometric data as described above. I understand that
                  this processing is necessary for document verification and that my data will be handled securely and
                  in accordance with privacy regulations.
                </Label>
              </div>
            </CardContent>
          </Card>

          {/* Error Message */}
          {errorMessage && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{errorMessage}</AlertDescription>
            </Alert>
          )}

          {/* Upload Button */}
          <Button
            onClick={handleUpload}
            disabled={!selectedFile || !documentType || !consentGiven || uploadStatus === "uploading"}
            className="w-full"
            size="lg"
          >
            {uploadStatus === "uploading" ? "Starting Verification..." : "Upload & Start Verification"}
          </Button>
        </div>
      </main>
    </div>
  )
}
