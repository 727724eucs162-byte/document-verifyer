"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Shield,
  FileText,
  Users,
  TrendingUp,
  Clock,
  CheckCircle,
  Hash,
  Search,
  Download,
  Eye,
  BarChart3,
  Activity,
} from "lucide-react"
import Link from "next/link"
import { getAllVerifiedDocuments, getVerificationStats, type VerifiedDocument } from "@/lib/mock-database"

export default function DashboardPage() {
  const [verifiedDocs, setVerifiedDocs] = useState<VerifiedDocument[]>([])
  const [stats, setStats] = useState<any>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [filterType, setFilterType] = useState<string>("all")
  const [filterStatus, setFilterStatus] = useState<string>("all")
  const [selectedDoc, setSelectedDoc] = useState<VerifiedDocument | null>(null)

  useEffect(() => {
    // Load verification data
    const docs = getAllVerifiedDocuments()
    const statistics = getVerificationStats()
    setVerifiedDocs(docs)
    setStats(statistics)
  }, [])

  const filteredDocs = verifiedDocs.filter((doc) => {
    const matchesSearch =
      searchQuery === "" ||
      doc.hashId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.documentType.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesType = filterType === "all" || doc.documentType === filterType
    const matchesStatus =
      filterStatus === "all" ||
      (filterStatus === "valid" && doc.isValid) ||
      (filterStatus === "invalid" && !doc.isValid) ||
      (filterStatus === "biometric" && doc.biometricVerified)

    return matchesSearch && matchesType && matchesStatus
  })

  const getStatusColor = (doc: VerifiedDocument) => {
    if (!doc.isValid) return "bg-destructive text-destructive-foreground"
    if (doc.biometricVerified && doc.verificationLevel === "premium") return "bg-primary text-primary-foreground"
    return "bg-secondary text-secondary-foreground"
  }

  const getStatusText = (doc: VerifiedDocument) => {
    if (!doc.isValid) return "Invalid"
    if (doc.biometricVerified && doc.verificationLevel === "premium") return "Premium Verified"
    if (doc.biometricVerified) return "Biometric Verified"
    return "Basic Verified"
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold text-foreground">Verification Dashboard</h1>
                <p className="text-sm text-muted-foreground">System overview and document management</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Link href="/">
                <Button variant="outline">Back to Home</Button>
              </Link>
              <Button>
                <Download className="h-4 w-4 mr-2" />
                Export Data
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="space-y-8">
          {/* Statistics Cards */}
          {stats && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Verifications</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.total}</div>
                  <p className="text-xs text-muted-foreground">All time verifications</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Valid Documents</CardTitle>
                  <CheckCircle className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-primary">{stats.valid}</div>
                  <p className="text-xs text-muted-foreground">
                    {stats.total > 0 ? Math.round((stats.valid / stats.total) * 100) : 0}% success rate
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Biometric Verified</CardTitle>
                  <Users className="h-4 w-4 text-accent" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-accent">{stats.biometricVerified}</div>
                  <p className="text-xs text-muted-foreground">Enhanced security level</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Premium Level</CardTitle>
                  <TrendingUp className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.premium}</div>
                  <p className="text-xs text-muted-foreground">Highest verification tier</p>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Main Dashboard Tabs */}
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="documents">Documents</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="system">System</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Recent Activity */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Activity className="h-5 w-5" />
                      Recent Activity
                    </CardTitle>
                    <CardDescription>Latest document verifications</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {verifiedDocs.slice(0, 5).map((doc) => (
                        <div key={doc.hashId} className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="space-y-1">
                            <p className="text-sm font-medium">{doc.hashId}</p>
                            <p className="text-xs text-muted-foreground capitalize">
                              {doc.documentType} • {new Date(doc.verificationDate).toLocaleDateString()}
                            </p>
                          </div>
                          <Badge className={getStatusColor(doc)}>{getStatusText(doc)}</Badge>
                        </div>
                      ))}
                      {verifiedDocs.length === 0 && (
                        <p className="text-center text-muted-foreground py-8">No verifications yet</p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* System Health */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5" />
                      System Health
                    </CardTitle>
                    <CardDescription>Current system status</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">OCR Processing</span>
                        <Badge className="bg-primary text-primary-foreground">Online</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Biometric Engine</span>
                        <Badge className="bg-primary text-primary-foreground">Online</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Hash Generation</span>
                        <Badge className="bg-primary text-primary-foreground">Online</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Database</span>
                        <Badge className="bg-primary text-primary-foreground">Connected</Badge>
                      </div>
                    </div>

                    <Alert>
                      <CheckCircle className="h-4 w-4" />
                      <AlertDescription>All systems operational. Average processing time: 2.3 seconds</AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Documents Tab */}
            <TabsContent value="documents" className="space-y-6">
              {/* Search and Filters */}
              <Card>
                <CardHeader>
                  <CardTitle>Document Management</CardTitle>
                  <CardDescription>Search and manage verified documents</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col md:flex-row gap-4">
                    <div className="flex-1">
                      <Label htmlFor="search">Search Documents</Label>
                      <div className="relative">
                        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="search"
                          placeholder="Search by hash ID or document type..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-10"
                        />
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <div>
                        <Label htmlFor="type-filter">Type</Label>
                        <Select value={filterType} onValueChange={setFilterType}>
                          <SelectTrigger id="type-filter" className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Types</SelectItem>
                            <SelectItem value="pan">PAN</SelectItem>
                            <SelectItem value="aadhaar">Aadhaar</SelectItem>
                            <SelectItem value="certificate">Certificate</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="status-filter">Status</Label>
                        <Select value={filterStatus} onValueChange={setFilterStatus}>
                          <SelectTrigger id="status-filter" className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Status</SelectItem>
                            <SelectItem value="valid">Valid</SelectItem>
                            <SelectItem value="invalid">Invalid</SelectItem>
                            <SelectItem value="biometric">Biometric</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Documents List */}
              <Card>
                <CardHeader>
                  <CardTitle>Verified Documents ({filteredDocs.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {filteredDocs.map((doc) => (
                      <div
                        key={doc.hashId}
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <Hash className="h-4 w-4 text-muted-foreground" />
                            <code className="text-sm font-mono">{doc.hashId}</code>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="capitalize">{doc.documentType}</span>
                            <span>•</span>
                            <span>{new Date(doc.verificationDate).toLocaleDateString()}</span>
                            {doc.expiryDate && (
                              <>
                                <span>•</span>
                                <span className="flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  Expires {new Date(doc.expiryDate).toLocaleDateString()}
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={getStatusColor(doc)}>{getStatusText(doc)}</Badge>
                          <Button variant="outline" size="sm" onClick={() => setSelectedDoc(doc)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                    {filteredDocs.length === 0 && (
                      <div className="text-center py-12">
                        <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                        <p className="text-muted-foreground">No documents found matching your criteria</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Analytics Tab */}
            <TabsContent value="analytics" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Verification Trends</CardTitle>
                    <CardDescription>Document verification patterns over time</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64 flex items-center justify-center text-muted-foreground">
                      <div className="text-center">
                        <BarChart3 className="h-12 w-12 mx-auto mb-2" />
                        <p>Analytics chart would be displayed here</p>
                        <p className="text-sm">Integration with charting library needed</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Document Types</CardTitle>
                    <CardDescription>Distribution of verified document types</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {["pan", "aadhaar", "certificate"].map((type) => {
                        const count = verifiedDocs.filter((doc) => doc.documentType === type).length
                        const percentage = verifiedDocs.length > 0 ? (count / verifiedDocs.length) * 100 : 0
                        return (
                          <div key={type} className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="capitalize">{type}</span>
                              <span>
                                {count} ({Math.round(percentage)}%)
                              </span>
                            </div>
                            <div className="w-full bg-muted rounded-full h-2">
                              <div
                                className="bg-primary h-2 rounded-full transition-all"
                                style={{ width: `${percentage}%` }}
                              />
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* System Tab */}
            <TabsContent value="system" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>System Configuration</CardTitle>
                    <CardDescription>Current system settings and parameters</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <Label className="text-muted-foreground">OCR Confidence Threshold</Label>
                        <p className="font-medium">85%</p>
                      </div>
                      <div>
                        <Label className="text-muted-foreground">Biometric Match Threshold</Label>
                        <p className="font-medium">80%</p>
                      </div>
                      <div>
                        <Label className="text-muted-foreground">Hash Expiry Period</Label>
                        <p className="font-medium">1 Year</p>
                      </div>
                      <div>
                        <Label className="text-muted-foreground">Max File Size</Label>
                        <p className="font-medium">10 MB</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Security Status</CardTitle>
                    <CardDescription>Security features and compliance</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Local AI Processing</span>
                      <CheckCircle className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Data Encryption</span>
                      <CheckCircle className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Privacy Compliance</span>
                      <CheckCircle className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Audit Logging</span>
                      <CheckCircle className="h-4 w-4 text-primary" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Document Detail Modal */}
      {selectedDoc && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <Card className="max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <CardHeader>
              <CardTitle>Document Details</CardTitle>
              <CardDescription>Verification information for {selectedDoc.hashId}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">Hash ID</Label>
                  <p className="font-mono text-sm">{selectedDoc.hashId}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Document Type</Label>
                  <p className="capitalize">{selectedDoc.documentType}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Verification Date</Label>
                  <p>{new Date(selectedDoc.verificationDate).toLocaleString()}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Status</Label>
                  <Badge className={getStatusColor(selectedDoc)}>{getStatusText(selectedDoc)}</Badge>
                </div>
                <div>
                  <Label className="text-muted-foreground">Biometric Verified</Label>
                  <p>{selectedDoc.biometricVerified ? "Yes" : "No"}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Verification Level</Label>
                  <p className="capitalize">{selectedDoc.verificationLevel || "Standard"}</p>
                </div>
                {selectedDoc.expiryDate && (
                  <div>
                    <Label className="text-muted-foreground">Expires</Label>
                    <p>{new Date(selectedDoc.expiryDate).toLocaleDateString()}</p>
                  </div>
                )}
              </div>
              <div className="flex gap-2 pt-4">
                <Button variant="outline" onClick={() => setSelectedDoc(null)} className="flex-1 bg-transparent">
                  Close
                </Button>
                <Button variant="outline" className="flex-1 bg-transparent">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
