import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Shield, FileText, Camera, Hash, CheckCircle, BarChart3 } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold text-foreground">SecureVerify</h1>
                <p className="text-sm text-muted-foreground">Document Verification System</p>
              </div>
            </div>
            <Link href="/dashboard">
              <Button variant="outline">
                <BarChart3 className="h-4 w-4 mr-2" />
                Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Hero Section */}
          <div className="text-center space-y-4">
            <h2 className="text-3xl font-bold text-foreground text-balance">Secure Document Verification with AI</h2>
            <p className="text-lg text-muted-foreground text-pretty max-w-2xl mx-auto">
              Verify your PAN cards, Aadhaar cards, and certificates using advanced OCR, biometric authentication, and
              hash-based security. Your privacy is our priority.
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center">
              <CardHeader>
                <FileText className="h-12 w-12 text-primary mx-auto mb-2" />
                <CardTitle className="text-lg">OCR Scanning</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Advanced optical character recognition for accurate document data extraction
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Camera className="h-12 w-12 text-primary mx-auto mb-2" />
                <CardTitle className="text-lg">Biometric Verify</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Live selfie matching with document photo for enhanced security</CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Hash className="h-12 w-12 text-primary mx-auto mb-2" />
                <CardTitle className="text-lg">Hash Security</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Unique hash IDs for verified documents - no need to re-upload</CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <CheckCircle className="h-12 w-12 text-primary mx-auto mb-2" />
                <CardTitle className="text-lg">Local AI</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>All processing happens locally for maximum privacy and security</CardDescription>
              </CardContent>
            </Card>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/upload">
              <Button size="lg" className="text-lg px-8">
                Start Verification
              </Button>
            </Link>
            <Link href="/verify-hash">
              <Button variant="outline" size="lg" className="text-lg px-8 bg-transparent">
                Verify with Hash ID
              </Button>
            </Link>
          </div>

          {/* Supported Documents */}
          <Card>
            <CardHeader>
              <CardTitle>Supported Documents</CardTitle>
              <CardDescription>We currently support verification for the following document types</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-3 gap-4">
                <div className="flex items-center gap-3 p-4 border border-border rounded-lg">
                  <FileText className="h-6 w-6 text-primary" />
                  <div>
                    <h4 className="font-medium">PAN Card</h4>
                    <p className="text-sm text-muted-foreground">Income Tax Department</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-4 border border-border rounded-lg">
                  <FileText className="h-6 w-6 text-primary" />
                  <div>
                    <h4 className="font-medium">Aadhaar Card</h4>
                    <p className="text-sm text-muted-foreground">UIDAI</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-4 border border-border rounded-lg">
                  <FileText className="h-6 w-6 text-primary" />
                  <div>
                    <h4 className="font-medium">Certificates</h4>
                    <p className="text-sm text-muted-foreground">Educational & Professional</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
