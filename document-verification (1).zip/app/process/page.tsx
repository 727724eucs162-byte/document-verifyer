"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Shield, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { OCRScanner } from "@/components/ocr-scanner"
import type { OCRResult } from "@/lib/ocr-processor"
import { updateVerificationStep } from "@/lib/status-tracker"

export default function ProcessPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const [file, setFile] = useState<File | null>(null)
  const [documentType, setDocumentType] = useState<"pan" | "aadhaar" | "certificate" | null>(null)
  const [processingComplete, setProcessingComplete] = useState(false)
  const [ocrResult, setOcrResult] = useState<OCRResult | null>(null)
  const sessionId = (searchParams.get("sessionId") ||
    (typeof window !== "undefined" ? sessionStorage.getItem("sessionId") : null)) as string | null

  const didInit = useRef(false)
  const didCompleteRef = useRef(false)

  const typeParam = (searchParams.get("type") as "pan" | "aadhaar" | "certificate" | null) || null
  const fileNameParam = searchParams.get("fileName") || "document.jpg"

  useEffect(() => {
    if (didInit.current) return
    if (!typeParam) return

    didInit.current = true
    setDocumentType(typeParam)
    const mockFile = new File(["mock content"], fileNameParam, { type: "image/jpeg" })
    setFile(mockFile)
  }, [typeParam, fileNameParam])

  const handleProcessingComplete = useCallback(
    (result: OCRResult) => {
      if (didCompleteRef.current) return
      didCompleteRef.current = true

      setOcrResult(result)
      setProcessingComplete(true)

      if (sessionId) {
        updateVerificationStep(
          sessionId,
          "ocr",
          "completed",
          "OCR completed and data extracted",
          result.confidence ?? 0.9,
        )
        if (documentType === "aadhaar") {
          updateVerificationStep(sessionId, "qr", "completed", "QR scan parsed successfully", 0.9)
        }
      }
    },
    [sessionId, documentType],
  )

  const proceedToVerification = useCallback(() => {
    if (!ocrResult) return

    // Persist OCR and mocked biometric in sessionStorage for final step
    sessionStorage.setItem("ocrResult", JSON.stringify(ocrResult))
    const mockedBiometric = {
      isMatch: true,
      confidence: 0.92,
      livenessPassed: true,
      method: "skipped",
    }
    sessionStorage.setItem("biometricResult", JSON.stringify(mockedBiometric))

    if (sessionId) {
      updateVerificationStep(sessionId, "biometric", "skipped", "Biometric step skipped per settings", 0.92)
    }

    const next = sessionId ? `/final-verification?sessionId=${sessionId}` : "/final-verification"
    router.push(next)
  }, [ocrResult, router, sessionId])

  if (!file || !documentType) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Invalid Request</CardTitle>
            <CardDescription>No document found for processing</CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/upload">
              <Button>Upload Document</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <Link href="/upload">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold text-foreground">Document Processing</h1>
                <p className="text-sm text-muted-foreground">AI-powered OCR and QR scanning</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Document Info */}
          <Card>
            <CardHeader>
              <CardTitle>Processing {documentType.toUpperCase()} Document</CardTitle>
              <CardDescription>
                File: {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
              </CardDescription>
            </CardHeader>
          </Card>

          {/* Privacy Notice */}
          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>
              All processing is happening locally on your device. Your document data is not transmitted to any external
              servers.
            </AlertDescription>
          </Alert>

          {/* OCR Scanner Component */}
          <OCRScanner file={file} documentType={documentType} onProcessingComplete={handleProcessingComplete} />

          {/* Next Steps */}
          {processingComplete && (
            <Card>
              <CardHeader>
                <CardTitle>Processing Complete</CardTitle>
                <CardDescription>
                  Document data has been successfully extracted. Proceed to verification.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <Button onClick={proceedToVerification} className="flex-1">
                    Proceed to Verification
                  </Button>
                  <Link href="/upload">
                    <Button variant="outline">Process Another Document</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}
