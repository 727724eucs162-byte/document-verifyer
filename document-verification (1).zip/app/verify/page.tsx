"use client"

import { useState, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Shield, ArrowLeft, FileText } from "lucide-react"
import Link from "next/link"
import { BiometricVerification } from "@/components/biometric-verification"
import type { OCRResult } from "@/lib/ocr-processor"
import type { BiometricResult } from "@/lib/biometric-processor"
import { updateVerificationStep } from "@/lib/status-tracker"

export default function VerifyPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const sessionId = (searchParams.get("sessionId") ||
    (typeof window !== "undefined" ? sessionStorage.getItem("sessionId") : null)) as string | null

  const [ocrResult, setOcrResult] = useState<OCRResult | null>(null)
  const [biometricResult, setBiometricResult] = useState<BiometricResult | null>(null)
  const [verificationComplete, setVerificationComplete] = useState(false)

  useEffect(() => {
    // Get OCR result from session storage
    const storedOcrResult = sessionStorage.getItem("ocrResult")
    if (storedOcrResult) {
      setOcrResult(JSON.parse(storedOcrResult))
    }
  }, [])

  const handleBiometricComplete = (result: BiometricResult) => {
    setBiometricResult(result)
    setVerificationComplete(true)
    if (sessionId) {
      updateVerificationStep(
        sessionId,
        "biometric",
        "completed",
        result.isMatch ? "Face matched successfully" : "Face match failed",
        result.confidence,
      )
      // For demo: mark validation after biometric completion
      updateVerificationStep(sessionId, "validation", "completed", "Cross-check complete", 0.9)
    }
  }

  const proceedToFinalStep = () => {
    // Store both results for final processing
    if (ocrResult && biometricResult) {
      sessionStorage.setItem("biometricResult", JSON.stringify(biometricResult))
      const next = sessionId ? `/final-verification?sessionId=${sessionId}` : "/final-verification"
      router.push(next)
    }
  }

  if (!ocrResult) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>No Document Data</CardTitle>
            <CardDescription>Please upload and process a document first</CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/upload">
              <Button>Upload Document</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <Link href="/process">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold text-foreground">Biometric Verification</h1>
                <p className="text-sm text-muted-foreground">Identity verification using live selfie</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Document Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document Summary
              </CardTitle>
              <CardDescription>
                Extracted data from your {ocrResult.documentType.toUpperCase()} document
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <label className="font-medium text-muted-foreground">Document Type</label>
                  <p className="capitalize">{ocrResult.documentType}</p>
                </div>
                <div>
                  <label className="font-medium text-muted-foreground">Name</label>
                  <p>{ocrResult.extractedData.name || "N/A"}</p>
                </div>
                <div>
                  <label className="font-medium text-muted-foreground">Document Number</label>
                  <p className="font-mono">{ocrResult.extractedData.documentNumber || "N/A"}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Privacy Notice */}
          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>
              Your biometric data is processed locally using AI and is never transmitted or stored on external servers.
              This ensures maximum privacy and security.
            </AlertDescription>
          </Alert>

          {/* Biometric Verification Component */}
          <BiometricVerification
            documentImageUrl="/person-face-document-photo.png"
            onVerificationComplete={handleBiometricComplete}
          />

          {/* Final Step */}
          {verificationComplete && biometricResult?.isMatch && (
            <Card className="border-primary/20 bg-primary/5">
              <CardHeader>
                <CardTitle>Verification Complete</CardTitle>
                <CardDescription>
                  Both document and biometric verification have been completed successfully
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={proceedToFinalStep} className="w-full" size="lg">
                  Generate Hash ID & Complete Verification
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}
