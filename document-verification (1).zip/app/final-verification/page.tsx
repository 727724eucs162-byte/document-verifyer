"use client"

import { Label } from "@/components/ui/label"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import {
  Shield,
  ArrowLeft,
  Hash,
  CheckCircle,
  Copy,
  Download,
  QrCode,
  Loader2,
  FileText,
  User,
  Clock,
} from "lucide-react"
import Link from "next/link"
import type { OCRResult } from "@/lib/ocr-processor"
import type { BiometricResult } from "@/lib/biometric-processor"
import {
  generateDocumentHash,
  generateHashId,
  getSecurityFeatures,
  type GeneratedHash,
  type HashGenerationData,
} from "@/lib/hash-generator"
import { storeVerifiedDocument, findDocumentByNumber } from "@/lib/mock-database"
import { useSearchParams } from "next/navigation"
import { updateVerificationStep, completeVerificationSession } from "@/lib/status-tracker"

export default function FinalVerificationPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const sessionId =
    (searchParams.get("sessionId") as string | null) ||
    (typeof window !== "undefined" ? (sessionStorage.getItem("sessionId") as string | null) : null)

  const [ocrResult, setOcrResult] = useState<OCRResult | null>(null)
  const [biometricResult, setBiometricResult] = useState<BiometricResult | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedHash, setGeneratedHash] = useState<GeneratedHash | null>(null)
  const [processingStep, setProcessingStep] = useState<"validating" | "hashing" | "storing" | "complete">("validating")
  const [progress, setProgress] = useState(0)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    // Get results from session storage
    const storedOcrResult = sessionStorage.getItem("ocrResult")
    const storedBiometricResult = sessionStorage.getItem("biometricResult")

    if (storedOcrResult) setOcrResult(JSON.parse(storedOcrResult))
    if (storedBiometricResult) setBiometricResult(JSON.parse(storedBiometricResult))
  }, [])

  const generateHash = async () => {
    if (!ocrResult || !biometricResult) return

    setIsGenerating(true)
    setProgress(0)

    try {
      setProcessingStep("validating")
      setProgress(25)
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setProcessingStep("hashing")
      setProgress(50)

      const hashData: HashGenerationData = {
        documentType: ocrResult.documentType,
        documentNumber: ocrResult.extractedData.documentNumber || "",
        extractedData: ocrResult.extractedData,
        biometricVerified: biometricResult.isMatch,
        ocrConfidence: ocrResult.confidence,
        biometricConfidence: biometricResult.confidence,
        timestamp: new Date().toISOString(),
      }

      // changed to await (Web Crypto)
      const documentHash = await generateDocumentHash(hashData)
      const generatedHashData = generateHashId(documentHash)

      await new Promise((resolve) => setTimeout(resolve, 1500))

      setProcessingStep("storing")
      setProgress(75)

      const originalDoc = findDocumentByNumber(ocrResult.extractedData.documentNumber || "", ocrResult.documentType)

      if (originalDoc) {
        // pass the already-generated hashId so DB uses it as-is
        storeVerifiedDocument(
          originalDoc,
          biometricResult.isMatch,
          ocrResult.confidence,
          biometricResult.confidence,
          generatedHashData.hashId,
          generatedHashData.verificationLevel,
          generatedHashData.expiryDate,
        )
      }

      await new Promise((resolve) => setTimeout(resolve, 1000))

      if (sessionId) {
        updateVerificationStep(sessionId, "hash", "completed", "Hash generated successfully")
        completeVerificationSession(sessionId, generatedHashData.hashId)
      }

      setProcessingStep("complete")
      setProgress(100)
      setGeneratedHash(generatedHashData)
    } catch (error) {
      console.error("[v0] Hash generation failed:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  const copyHashId = async () => {
    if (generatedHash) {
      await navigator.clipboard.writeText(generatedHash.hashId)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const downloadCertificate = () => {
    if (!generatedHash || !ocrResult) return

    const certificateData = {
      hashId: generatedHash.hashId,
      documentType: ocrResult.documentType,
      verificationDate: new Date().toISOString(),
      verificationLevel: generatedHash.verificationLevel,
      expiryDate: generatedHash.expiryDate,
      securityFeatures: getSecurityFeatures(generatedHash.verificationLevel),
    }

    const blob = new Blob([JSON.stringify(certificateData, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `verification-certificate-${generatedHash.shortHash}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  if (!ocrResult || !biometricResult) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Incomplete Verification</CardTitle>
            <CardDescription>Please complete document processing and biometric verification first</CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/upload">
              <Button>Start Over</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <Link href="/verify">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold text-foreground">Final Verification</h1>
                <p className="text-sm text-muted-foreground">Generate secure hash ID</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Verification Summary */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Document Verification
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Document Type</span>
                  <span className="capitalize font-medium">{ocrResult.documentType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">OCR Confidence</span>
                  <Badge className="bg-primary text-primary-foreground">
                    {Math.round(ocrResult.confidence * 100)}%
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Data Extracted</span>
                  <CheckCircle className="h-5 w-5 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Biometric Verification
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Face Match</span>
                  <Badge
                    className={
                      biometricResult.isMatch
                        ? "bg-primary text-primary-foreground"
                        : "bg-destructive text-destructive-foreground"
                    }
                  >
                    {biometricResult.isMatch ? "Verified" : "Failed"}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Match Confidence</span>
                  <span className="font-medium">{Math.round(biometricResult.confidence * 100)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Liveness Check</span>
                  {biometricResult.livenessPassed ? (
                    <CheckCircle className="h-5 w-5 text-primary" />
                  ) : (
                    <span className="text-destructive">Failed</span>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Hash Generation */}
          {!generatedHash && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Hash className="h-5 w-5" />
                  Generate Secure Hash ID
                </CardTitle>
                <CardDescription>
                  Create a unique hash identifier for your verified document that can be used for future verification
                  without re-uploading
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {!isGenerating ? (
                  <Button onClick={generateHash} className="w-full" size="lg">
                    Generate Hash ID
                  </Button>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <Loader2 className="h-5 w-5 animate-spin text-primary" />
                      <span className="text-sm">
                        {processingStep === "validating" && "Validating verification data..."}
                        {processingStep === "hashing" && "Generating cryptographic hash..."}
                        {processingStep === "storing" && "Storing verification record..."}
                        {processingStep === "complete" && "Hash generation complete!"}
                      </span>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{progress}%</span>
                      </div>
                      <Progress value={progress} className="w-full" />
                    </div>
                  </div>
                )}

                <Alert>
                  <Shield className="h-4 w-4" />
                  <AlertDescription>
                    Your hash ID is generated using cryptographic algorithms and stored securely. It cannot be reverse
                    engineered to reveal your personal information.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          )}

          {/* Generated Hash Results */}
          {generatedHash && (
            <Card className="border-primary/20 bg-primary/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-primary" />
                  Verification Complete
                </CardTitle>
                <CardDescription>
                  Your document has been successfully verified and a hash ID has been generated
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Hash ID Display */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Your Hash ID</Label>
                  <div className="flex items-center gap-2 p-3 bg-background rounded-lg border">
                    <code className="flex-1 font-mono text-lg">{generatedHash.hashId}</code>
                    <Button variant="outline" size="sm" onClick={copyHashId}>
                      <Copy className="h-4 w-4" />
                      {copied ? "Copied!" : "Copy"}
                    </Button>
                  </div>
                </div>

                {/* Verification Details */}
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <Label className="text-sm text-muted-foreground">Verification Level</Label>
                    <Badge className="bg-primary text-primary-foreground capitalize">
                      {generatedHash.verificationLevel}
                    </Badge>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-sm text-muted-foreground">Valid Until</Label>
                    <p className="text-sm flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {new Date(generatedHash.expiryDate).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-sm text-muted-foreground">Security Features</Label>
                    <div className="flex gap-1">
                      {Object.entries(getSecurityFeatures(generatedHash.verificationLevel)).map(([feature, enabled]) =>
                        enabled ? (
                          <Badge key={feature} variant="outline" className="text-xs">
                            {feature.charAt(0).toUpperCase()}
                          </Badge>
                        ) : null,
                      )}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button onClick={downloadCertificate} variant="outline" className="flex-1 bg-transparent">
                    <Download className="h-4 w-4 mr-2" />
                    Download Certificate
                  </Button>
                  <Button variant="outline" className="flex-1 bg-transparent">
                    <QrCode className="h-4 w-4 mr-2" />
                    Generate QR Code
                  </Button>
                  <Link href="/" className="flex-1">
                    <Button className="w-full">Complete</Button>
                  </Link>
                </div>

                {/* Important Notice */}
                <Alert>
                  <AlertDescription>
                    <strong>Important:</strong> Save your Hash ID securely. You can use it to verify this document in
                    the future without re-uploading. This ID expires on{" "}
                    {new Date(generatedHash.expiryDate).toLocaleDateString()}.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}
