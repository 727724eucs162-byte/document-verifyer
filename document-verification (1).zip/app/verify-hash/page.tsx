"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Shield, ArrowLeft, Hash, CheckCircle, XCircle } from "lucide-react"
import Link from "next/link"
import { findVerifiedDocumentByHash } from "@/lib/mock-database"

export default function VerifyHashPage() {
  const [hashId, setHashId] = useState("")
  const [verificationResult, setVerificationResult] = useState<any>(null)
  const [isVerifying, setIsVerifying] = useState(false)
  const [error, setError] = useState("")

  const handleVerify = async () => {
    if (!hashId.trim()) {
      setError("Please enter a hash ID")
      return
    }

    setIsVerifying(true)
    setError("")
    setVerificationResult(null)

    try {
      // Simulate verification delay
      await new Promise((resolve) => setTimeout(resolve, 1500))

      const result = findVerifiedDocumentByHash(hashId.trim())

      if (result) {
        setVerificationResult(result)
      } else {
        setError("Hash ID not found. Please check and try again.")
      }
    } catch (err) {
      setError("Verification failed. Please try again.")
    } finally {
      setIsVerifying(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold text-foreground">Hash Verification</h1>
                <p className="text-sm text-muted-foreground">Verify document using hash ID</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Hash className="h-5 w-5" />
                Enter Hash ID
              </CardTitle>
              <CardDescription>
                Enter the hash ID you received after document verification to check its status
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="hashId">Hash ID</Label>
                <Input
                  id="hashId"
                  placeholder="e.g., HASH_ABC123XYZ"
                  value={hashId}
                  onChange={(e) => setHashId(e.target.value)}
                  className="font-mono"
                />
              </div>

              <Button onClick={handleVerify} disabled={isVerifying} className="w-full">
                {isVerifying ? "Verifying..." : "Verify Hash ID"}
              </Button>
            </CardContent>
          </Card>

          {error && (
            <Alert variant="destructive">
              <XCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {verificationResult && (
            <Card
              className={
                verificationResult.isValid ? "border-primary/20 bg-primary/5" : "border-destructive/20 bg-destructive/5"
              }
            >
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {verificationResult.isValid ? (
                    <CheckCircle className="h-5 w-5 text-primary" />
                  ) : (
                    <XCircle className="h-5 w-5 text-destructive" />
                  )}
                  Verification Result
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <Label className="text-muted-foreground">Hash ID</Label>
                    <p className="font-mono">{verificationResult.hashId}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Document Type</Label>
                    <p className="capitalize">{verificationResult.documentType}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Verification Date</Label>
                    <p>{new Date(verificationResult.verificationDate).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Status</Label>
                    <p
                      className={
                        verificationResult.isValid ? "text-primary font-medium" : "text-destructive font-medium"
                      }
                    >
                      {verificationResult.isValid ? "Valid" : "Invalid"}
                    </p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Biometric Verified</Label>
                    <p className={verificationResult.biometricVerified ? "text-primary" : "text-muted-foreground"}>
                      {verificationResult.biometricVerified ? "Yes" : "No"}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}
