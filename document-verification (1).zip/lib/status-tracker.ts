export interface VerificationStep {
  id: string
  name: string
  description: string
  status: "pending" | "in-progress" | "completed" | "failed"
  timestamp?: string
  duration?: number
  details?: string
  confidence?: number
}

export interface VerificationSession {
  sessionId: string
  documentType: "pan" | "aadhaar" | "certificate"
  fileName: string
  startTime: string
  currentStep: string
  overallStatus: "uploading" | "processing" | "verifying" | "completed" | "failed"
  steps: VerificationStep[]
  hashId?: string
  estimatedTimeRemaining?: number
}

// Mock verification sessions storage
export const verificationSessions: VerificationSession[] = []

export function createVerificationSession(
  documentType: "pan" | "aadhaar" | "certificate",
  fileName: string,
): VerificationSession {
  const sessionId = "SESSION_" + Math.random().toString(36).substr(2, 9).toUpperCase()

  const steps: VerificationStep[] = [
    {
      id: "upload",
      name: "Document Upload",
      description: "Uploading and validating document file",
      status: "completed",
      timestamp: new Date().toISOString(),
      duration: 2000,
    },
    {
      id: "consent",
      name: "Privacy Consent",
      description: "Confirming data processing consent",
      status: "completed",
      timestamp: new Date().toISOString(),
      duration: 500,
    },
    {
      id: "ocr",
      name: "OCR Processing",
      description: "Extracting text and data from document",
      status: "in-progress",
    },
    {
      id: "qr",
      name: "QR Code Scan",
      description:
        documentType === "aadhaar" ? "Scanning QR code for additional verification" : "Skipped for this document type",
      status: documentType === "aadhaar" ? "pending" : "completed",
    },
    {
      id: "biometric",
      name: "Biometric Verification",
      description: "Live selfie capture and face matching",
      status: "pending",
    },
    {
      id: "validation",
      name: "Document Validation",
      description: "Cross-referencing with official databases",
      status: "pending",
    },
    {
      id: "hash",
      name: "Hash Generation",
      description: "Creating secure hash ID for verified document",
      status: "pending",
    },
  ]

  const session: VerificationSession = {
    sessionId,
    documentType,
    fileName,
    startTime: new Date().toISOString(),
    currentStep: "ocr",
    overallStatus: "processing",
    steps,
    estimatedTimeRemaining: 180, // 3 minutes
  }

  verificationSessions.push(session)
  return session
}

export function updateVerificationStep(
  sessionId: string,
  stepId: string,
  status: "pending" | "in-progress" | "completed" | "failed",
  details?: string,
  confidence?: number,
): void {
  const session = verificationSessions.find((s) => s.sessionId === sessionId)
  if (!session) return

  const step = session.steps.find((s) => s.id === stepId)
  if (!step) return

  step.status = status
  step.details = details
  step.confidence = confidence

  if (status === "completed" || status === "failed") {
    step.timestamp = new Date().toISOString()
    step.duration = Math.floor(Math.random() * 3000) + 1000 // 1-4 seconds
  }

  // Update current step and overall status
  if (status === "completed") {
    const currentIndex = session.steps.findIndex((s) => s.id === stepId)
    const nextStep = session.steps[currentIndex + 1]
    if (nextStep && nextStep.status === "pending") {
      session.currentStep = nextStep.id
      nextStep.status = "in-progress"
    } else if (!nextStep) {
      session.overallStatus = "completed"
      session.currentStep = "completed"
    }
  } else if (status === "failed") {
    session.overallStatus = "failed"
  }

  // Update estimated time remaining
  const completedSteps = session.steps.filter((s) => s.status === "completed").length
  const totalSteps = session.steps.length
  const progress = completedSteps / totalSteps
  session.estimatedTimeRemaining = Math.max(0, Math.floor((1 - progress) * 120)) // Max 2 minutes remaining
}

export function getVerificationSession(sessionId: string): VerificationSession | null {
  return verificationSessions.find((s) => s.sessionId === sessionId) || null
}

export function completeVerificationSession(sessionId: string, hashId: string): void {
  const session = verificationSessions.find((s) => s.sessionId === sessionId)
  if (!session) return

  session.hashId = hashId
  session.overallStatus = "completed"
  session.currentStep = "completed"
  session.estimatedTimeRemaining = 0

  // Mark all remaining steps as completed
  session.steps.forEach((step) => {
    if (step.status === "pending" || step.status === "in-progress") {
      step.status = "completed"
      step.timestamp = new Date().toISOString()
    }
  })
}

export function getSessionProgress(session: VerificationSession): number {
  const completedSteps = session.steps.filter((s) => s.status === "completed").length
  return Math.round((completedSteps / session.steps.length) * 100)
}

export function getEstimatedTimeRemaining(session: VerificationSession): string {
  if (!session.estimatedTimeRemaining || session.estimatedTimeRemaining <= 0) {
    return "Almost done"
  }

  const minutes = Math.floor(session.estimatedTimeRemaining / 60)
  const seconds = session.estimatedTimeRemaining % 60

  if (minutes > 0) {
    return `${minutes}m ${seconds}s remaining`
  }
  return `${seconds}s remaining`
}
