// Simulated OCR processing for different document types
export interface OCRResult {
  documentType: "pan" | "aadhaar" | "certificate"
  extractedData: {
    documentNumber?: string
    name?: string
    fatherName?: string
    dateOfBirth?: string
    address?: string
    issueDate?: string
    validUntil?: string
    [key: string]: string | undefined
  }
  confidence: number
  qrCodeData?: string
}

// Mock OCR processing function
export async function processDocumentOCR(
  file: File,
  documentType: "pan" | "aadhaar" | "certificate",
): Promise<OCRResult> {
  // Simulate processing time
  await new Promise((resolve) => setTimeout(resolve, 3000))

  // Mock OCR results based on document type
  const mockResults: Record<string, OCRResult> = {
    pan: {
      documentType: "pan",
      extractedData: {
        documentNumber: "ABCDE1234F",
        name: "RAJESH KUMAR",
        fatherName: "SURESH KUMAR",
        dateOfBirth: "15/05/1990",
        issueDate: "20/03/2015",
      },
      confidence: 0.95,
    },
    aadhaar: {
      documentType: "aadhaar",
      extractedData: {
        documentNumber: "1234-5678-9012",
        name: "Rajesh Kumar",
        dateOfBirth: "15/05/1990",
        address: "123 Main Street, Delhi, 110001",
        issueDate: "25/08/2016",
      },
      confidence: 0.92,
      qrCodeData: '<?xml version="1.0" encoding="UTF-8"?><PrintLetterBarcodeData>...</PrintLetterBarcodeData>',
    },
    certificate: {
      documentType: "certificate",
      extractedData: {
        documentNumber: "GRAD2020001",
        name: "RAJESH KUMAR",
        dateOfBirth: "15/05/1990",
        issueDate: "15/06/2020",
        validUntil: "15/06/2030",
      },
      confidence: 0.88,
    },
  }

  return mockResults[documentType] || mockResults.pan
}

// QR Code processing function
export async function processQRCode(imageData: string): Promise<string | null> {
  // Simulate QR code processing
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Mock QR code data for Aadhaar
  const mockQRData = `<?xml version="1.0" encoding="UTF-8"?>
<PrintLetterBarcodeData uid="1234567890123" name="Rajesh Kumar" gender="M" yob="1990" co="S/O Suresh Kumar" house="" street="123 Main Street" lm="" loc="" vtc="" po="" dist="Delhi" state="Delhi" pc="110001" dob="15/05/1990"/>`

  return Math.random() > 0.3 ? mockQRData : null
}

// Parse QR code XML data
export function parseAadhaarQR(qrData: string): Record<string, string> {
  const parser = new DOMParser()
  const xmlDoc = parser.parseFromString(qrData, "text/xml")
  const barcodeData = xmlDoc.getElementsByTagName("PrintLetterBarcodeData")[0]

  if (!barcodeData) return {}

  const attributes = barcodeData.attributes
  const result: Record<string, string> = {}

  for (let i = 0; i < attributes.length; i++) {
    const attr = attributes[i]
    result[attr.name] = attr.value
  }

  return result
}
