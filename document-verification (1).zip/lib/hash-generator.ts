export interface HashGenerationData {
  documentType: "pan" | "aadhaar" | "certificate"
  documentNumber: string
  extractedData: Record<string, string | undefined>
  biometricVerified: boolean
  ocrConfidence: number
  biometricConfidence: number
  timestamp: string
}

export interface GeneratedHash {
  hashId: string
  shortHash: string
  verificationLevel: "basic" | "standard" | "premium"
  expiryDate: string
  metadata: {
    documentType: string
    verificationDate: string
    biometricVerified: boolean
    confidenceScore: number
  }
}

// Generate cryptographic hash from document data
export async function generateDocumentHash(data: HashGenerationData): Promise<string> {
  const hashInput = JSON.stringify({
    type: data.documentType,
    number: data.documentNumber,
    name: data.extractedData.name,
    timestamp: data.timestamp,
    biometric: data.biometricVerified,
  })

  // Prefer Web Crypto (browser / modern runtimes)
  const g: any = globalThis as any
  if (g.crypto?.subtle) {
    const enc = new TextEncoder()
    const bytes = enc.encode(hashInput)
    const digest = await g.crypto.subtle.digest("SHA-256", bytes)
    const hashArray = Array.from(new Uint8Array(digest))
    const hex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")
    return hex
  }

  // Fallback to Node crypto if available (server)
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const nodeCrypto = require("crypto") as typeof import("crypto")
    return nodeCrypto.createHash("sha256").update(hashInput).digest("hex")
  } catch {
    throw new Error("Cryptographic hashing is not available in this environment.")
  }
}

// Generate user-friendly hash ID
export function generateHashId(documentHash: string): GeneratedHash {
  // Create a shorter, user-friendly hash
  const shortHash = documentHash.substring(0, 12).toUpperCase()
  const hashId = `HASH_${shortHash}`

  // Determine verification level based on biometric and OCR confidence
  const getVerificationLevel = (
    ocrConf: number,
    bioConf: number,
    bioVerified: boolean,
  ): "basic" | "standard" | "premium" => {
    if (bioVerified && bioConf >= 0.9 && ocrConf >= 0.9) return "premium"
    if (bioVerified && bioConf >= 0.8 && ocrConf >= 0.8) return "standard"
    return "basic"
  }

  // Set expiry date (1 year from now)
  const expiryDate = new Date()
  expiryDate.setFullYear(expiryDate.getFullYear() + 1)

  return {
    hashId,
    shortHash,
    verificationLevel: "premium", // Default for demo
    expiryDate: expiryDate.toISOString(),
    metadata: {
      documentType: "document",
      verificationDate: new Date().toISOString(),
      biometricVerified: true,
      confidenceScore: 0.95,
    },
  }
}

// Validate hash ID format
export function validateHashId(hashId: string): boolean {
  const hashPattern = /^HASH_[A-Z0-9]{12}$/
  return hashPattern.test(hashId)
}

// Generate QR code data for hash
export function generateHashQRData(hashId: string, metadata: any): string {
  return JSON.stringify({
    hashId,
    verificationUrl: `https://secureverify.app/verify/${hashId}`,
    timestamp: new Date().toISOString(),
    metadata,
  })
}

// Security features for hash
export interface SecurityFeatures {
  encryption: boolean
  digitalSignature: boolean
  timestamping: boolean
  blockchainAnchor: boolean
}

export function getSecurityFeatures(verificationLevel: "basic" | "standard" | "premium"): SecurityFeatures {
  switch (verificationLevel) {
    case "premium":
      return {
        encryption: true,
        digitalSignature: true,
        timestamping: true,
        blockchainAnchor: true,
      }
    case "standard":
      return {
        encryption: true,
        digitalSignature: true,
        timestamping: true,
        blockchainAnchor: false,
      }
    case "basic":
      return {
        encryption: true,
        digitalSignature: false,
        timestamping: true,
        blockchainAnchor: false,
      }
  }
}
