export interface Document {
  id: string
  type: "pan" | "aadhaar" | "certificate"
  documentNumber: string
  name: string
  dateOfBirth?: string
  fatherName?: string
  address?: string
  issueDate: string
  validUntil?: string
  isValid: boolean
  imageUrl?: string
}

// Mock PAN Card Database
export const mockPanDatabase: Document[] = [
  {
    id: "pan_001",
    type: "pan",
    documentNumber: "ABCDE1234F",
    name: "Rajesh Kumar",
    fatherName: "Suresh Kumar",
    dateOfBirth: "1990-05-15",
    issueDate: "2015-03-20",
    isValid: true,
  },
  {
    id: "pan_002",
    type: "pan",
    documentNumber: "FGHIJ5678K",
    name: "Priya Sharma",
    fatherName: "Mohan Sharma",
    dateOfBirth: "1985-12-08",
    issueDate: "2012-07-10",
    isValid: true,
  },
  {
    id: "pan_003",
    type: "pan",
    documentNumber: "LMNOP9012Q",
    name: "Amit Singh",
    fatherName: "Ravi Singh",
    dateOfBirth: "1992-09-22",
    issueDate: "2018-01-15",
    isValid: false, // Expired or invalid
  },
]

// Mock Aadhaar Database
export const mockAadhaarDatabase: Document[] = [
  {
    id: "aadhaar_001",
    type: "aadhaar",
    documentNumber: "1234-5678-9012",
    name: "Rajesh Kumar",
    dateOfBirth: "1990-05-15",
    address: "123 Main Street, Delhi, 110001",
    issueDate: "2016-08-25",
    isValid: true,
  },
  {
    id: "aadhaar_002",
    type: "aadhaar",
    documentNumber: "9876-5432-1098",
    name: "Priya Sharma",
    dateOfBirth: "1985-12-08",
    address: "456 Park Avenue, Mumbai, 400001",
    issueDate: "2014-11-12",
    isValid: true,
  },
  {
    id: "aadhaar_003",
    type: "aadhaar",
    documentNumber: "5555-4444-3333",
    name: "Amit Singh",
    dateOfBirth: "1992-09-22",
    address: "789 Garden Road, Bangalore, 560001",
    issueDate: "2017-04-30",
    isValid: false,
  },
]

// Mock Certificate Database
export const mockCertificateDatabase: Document[] = [
  {
    id: "cert_001",
    type: "certificate",
    documentNumber: "GRAD2020001",
    name: "Rajesh Kumar",
    dateOfBirth: "1990-05-15",
    issueDate: "2020-06-15",
    validUntil: "2030-06-15",
    isValid: true,
  },
  {
    id: "cert_002",
    type: "certificate",
    documentNumber: "GRAD2019045",
    name: "Priya Sharma",
    dateOfBirth: "1985-12-08",
    issueDate: "2019-05-20",
    validUntil: "2029-05-20",
    isValid: true,
  },
  {
    id: "cert_003",
    type: "certificate",
    documentNumber: "GRAD2021078",
    name: "Amit Singh",
    dateOfBirth: "1992-09-22",
    issueDate: "2021-07-10",
    validUntil: "2031-07-10",
    isValid: false,
  },
]

// Hash storage for verified documents
export interface VerifiedDocument {
  hashId: string
  originalDocumentId: string
  documentType: "pan" | "aadhaar" | "certificate"
  verificationDate: string
  isValid: boolean
  biometricVerified: boolean
  ocrConfidence?: number
  biometricConfidence?: number
  verificationLevel?: "basic" | "standard" | "premium"
  expiryDate?: string
}

export const verifiedDocumentsStore: VerifiedDocument[] = []

// Utility functions for database operations
export function findDocumentByNumber(documentNumber: string, type: "pan" | "aadhaar" | "certificate"): Document | null {
  let database: Document[]

  switch (type) {
    case "pan":
      database = mockPanDatabase
      break
    case "aadhaar":
      database = mockAadhaarDatabase
      break
    case "certificate":
      database = mockCertificateDatabase
      break
    default:
      return null
  }

  return database.find((doc) => doc.documentNumber === documentNumber) || null
}

export function generateHashId(): string {
  return "HASH_" + Math.random().toString(36).substr(2, 9).toUpperCase()
}

export function storeVerifiedDocument(
  document: Document,
  biometricVerified: boolean,
  ocrConfidence?: number,
  biometricConfidence?: number,
  providedHashId?: string,
  providedVerificationLevel?: "basic" | "standard" | "premium",
  providedExpiryDateISO?: string,
): string {
  const hashId = providedHashId ?? generateHashId()

  const expiryDateISO =
    providedExpiryDateISO ??
    (() => {
      const d = new Date()
      d.setFullYear(d.getFullYear() + 1)
      return d.toISOString()
    })()

  const computedLevel =
    providedVerificationLevel ?? (biometricVerified && (biometricConfidence || 0) > 0.8 ? "premium" : "standard")

  const verifiedDoc: VerifiedDocument = {
    hashId,
    originalDocumentId: document.id,
    documentType: document.type,
    verificationDate: new Date().toISOString(),
    isValid: document.isValid && biometricVerified,
    biometricVerified,
    ocrConfidence,
    biometricConfidence,
    verificationLevel: computedLevel,
    expiryDate: expiryDateISO,
  }

  verifiedDocumentsStore.push(verifiedDoc)
  return hashId
}

export function findVerifiedDocumentByHash(hashId: string): VerifiedDocument | null {
  return verifiedDocumentsStore.find((doc) => doc.hashId === hashId) || null
}

export function getAllVerifiedDocuments(): VerifiedDocument[] {
  return [...verifiedDocumentsStore]
}

export function getVerificationStats() {
  const total = verifiedDocumentsStore.length
  const valid = verifiedDocumentsStore.filter((doc) => doc.isValid).length
  const biometricVerified = verifiedDocumentsStore.filter((doc) => doc.biometricVerified).length
  const premium = verifiedDocumentsStore.filter((doc) => doc.verificationLevel === "premium").length

  return {
    total,
    valid,
    invalid: total - valid,
    biometricVerified,
    premium,
    standard: total - premium,
  }
}
