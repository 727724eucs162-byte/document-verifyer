"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, FileText, QrCode, CheckCircle, AlertCircle, Eye, EyeOff } from "lucide-react"
import { processDocumentOCR, processQRCode, parseAadhaarQR, type OCRResult } from "@/lib/ocr-processor"

interface OCRScannerProps {
  file: File
  documentType: "pan" | "aadhaar" | "certificate"
  onProcessingComplete: (result: OCRResult) => void
}

export function OCRScanner({ file, documentType, onProcessingComplete }: OCRScannerProps) {
  const [isProcessing, setIsProcessing] = useState(false)
  const [ocrResult, setOcrResult] = useState<OCRResult | null>(null)
  const [qrResult, setQrResult] = useState<string | null>(null)
  const [showSensitiveData, setShowSensitiveData] = useState(false)
  const [processingStep, setProcessingStep] = useState<"ocr" | "qr" | "complete">("ocr")

  const startProcessing = async () => {
    setIsProcessing(true)
    setProcessingStep("ocr")

    try {
      // Step 1: OCR Processing
      const ocrData = await processDocumentOCR(file, documentType)
      setOcrResult(ocrData)

      // Step 2: QR Code Processing (for Aadhaar)
      if (documentType === "aadhaar") {
        setProcessingStep("qr")
        const qrData = await processQRCode("")
        setQrResult(qrData)
      }

      setProcessingStep("complete")
      onProcessingComplete(ocrData)
    } catch (error) {
      console.error("Processing failed:", error)
    } finally {
      setIsProcessing(false)
    }
  }

  const maskSensitiveData = (value: string, type: "partial" | "full" = "partial"): string => {
    if (!value) return ""
    if (type === "full") return "*".repeat(value.length)

    if (value.includes("-")) {
      // Aadhaar format: 1234-5678-9012 -> 1234-****-9012
      const parts = value.split("-")
      return parts.map((part, index) => (index === 1 ? "*".repeat(part.length) : part)).join("-")
    }

    // Other formats: show first 2 and last 2 characters
    if (value.length > 4) {
      return value.slice(0, 2) + "*".repeat(value.length - 4) + value.slice(-2)
    }

    return value
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return "bg-primary text-primary-foreground"
    if (confidence >= 0.8) return "bg-yellow-500 text-yellow-50"
    return "bg-destructive text-destructive-foreground"
  }

  const getConfidenceText = (confidence: number) => {
    if (confidence >= 0.9) return "High"
    if (confidence >= 0.8) return "Medium"
    return "Low"
  }

  return (
    <div className="space-y-6">
      {/* Processing Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Document Processing
          </CardTitle>
          <CardDescription>
            Extracting data from your {documentType.toUpperCase()} document using AI-powered OCR
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!isProcessing && !ocrResult && (
            <Button onClick={startProcessing} className="w-full">
              Start Processing
            </Button>
          )}

          {isProcessing && (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Loader2 className="h-5 w-5 animate-spin text-primary" />
                <span className="text-sm">
                  {processingStep === "ocr" && "Extracting text using OCR..."}
                  {processingStep === "qr" && "Scanning for QR codes..."}
                </span>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <div
                    className={`w-2 h-2 rounded-full ${processingStep === "ocr" ? "bg-primary animate-pulse" : "bg-primary"}`}
                  />
                  OCR Text Extraction
                </div>
                {documentType === "aadhaar" && (
                  <div className="flex items-center gap-2 text-sm">
                    <div
                      className={`w-2 h-2 rounded-full ${processingStep === "qr" ? "bg-primary animate-pulse" : processingStep === "complete" ? "bg-primary" : "bg-muted"}`}
                    />
                    QR Code Scanning
                  </div>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* OCR Results */}
      {ocrResult && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                Extracted Data
              </CardTitle>
              <div className="flex items-center gap-2">
                <Badge className={getConfidenceColor(ocrResult.confidence)}>
                  {getConfidenceText(ocrResult.confidence)} Confidence ({Math.round(ocrResult.confidence * 100)}%)
                </Badge>
                <Button variant="outline" size="sm" onClick={() => setShowSensitiveData(!showSensitiveData)}>
                  {showSensitiveData ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  {showSensitiveData ? "Hide" : "Show"} Data
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(ocrResult.extractedData).map(([key, value]) => {
                if (!value) return null

                const isSensitive = ["documentNumber", "dateOfBirth", "address"].includes(key)
                const displayValue = showSensitiveData || !isSensitive ? value : maskSensitiveData(value)

                return (
                  <div key={key} className="space-y-1">
                    <label className="text-sm font-medium text-muted-foreground capitalize">
                      {key.replace(/([A-Z])/g, " $1").trim()}
                    </label>
                    <p className="text-sm font-mono bg-muted p-2 rounded">{displayValue}</p>
                  </div>
                )
              })}
            </div>

            {ocrResult.confidence < 0.8 && (
              <Alert className="mt-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Low confidence detected. Please ensure the document image is clear and well-lit for better accuracy.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* QR Code Results */}
      {qrResult && documentType === "aadhaar" && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <QrCode className="h-5 w-5 text-primary" />
              QR Code Data
            </CardTitle>
            <CardDescription>Additional verification data extracted from QR code</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  QR code successfully detected and parsed. This provides additional verification for authenticity.
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(parseAadhaarQR(qrResult)).map(([key, value]) => {
                  if (!value || key === "uid") return null

                  const isSensitive = ["uid", "dob", "house", "street"].includes(key)
                  const displayValue = showSensitiveData || !isSensitive ? value : maskSensitiveData(value)

                  return (
                    <div key={key} className="space-y-1">
                      <label className="text-sm font-medium text-muted-foreground capitalize">
                        {key === "yob"
                          ? "Year of Birth"
                          : key === "co"
                            ? "Care Of"
                            : key === "vtc"
                              ? "VTC"
                              : key === "po"
                                ? "Post Office"
                                : key === "pc"
                                  ? "Pin Code"
                                  : key}
                      </label>
                      <p className="text-sm font-mono bg-muted p-2 rounded">{displayValue}</p>
                    </div>
                  )
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
