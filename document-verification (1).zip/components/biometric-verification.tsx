"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Loader2, CheckCircle, XCircle, User, Shield, AlertCircle } from "lucide-react"
import { CameraCapture } from "./camera-capture"
import { compareFaces, detectFace, performLivenessCheck, type BiometricResult } from "@/lib/biometric-processor"

interface BiometricVerificationProps {
  documentImageUrl?: string
  onVerificationComplete: (result: BiometricResult) => void
}

export function BiometricVerification({ documentImageUrl, onVerificationComplete }: BiometricVerificationProps) {
  const [liveSelfie, setLiveSelfie] = useState<string>("")
  const [isVerifying, setIsVerifying] = useState(false)
  const [verificationStep, setVerificationStep] = useState<"capture" | "processing" | "complete">("capture")
  const [verificationResult, setVerificationResult] = useState<BiometricResult | null>(null)
  const [processingProgress, setProcessingProgress] = useState(0)

  const handleSelfieCapture = (imageData: string) => {
    setLiveSelfie(imageData)
  }

  const startVerification = async () => {
    if (!liveSelfie) return

    setIsVerifying(true)
    setVerificationStep("processing")
    setProcessingProgress(0)

    try {
      // Step 1: Face detection in live selfie
      setProcessingProgress(20)
      const liveFace = await detectFace(liveSelfie)

      if (!liveFace) {
        throw new Error("No face detected in selfie")
      }

      // Step 2: Liveness check
      setProcessingProgress(40)
      const livenessResult = await performLivenessCheck([liveSelfie])

      if (!livenessResult) {
        throw new Error("Liveness check failed")
      }

      // Step 3: Face comparison
      setProcessingProgress(60)
      const comparisonResult = await compareFaces(documentImageUrl || "", liveSelfie)

      setProcessingProgress(100)
      setVerificationResult(comparisonResult)
      setVerificationStep("complete")
      onVerificationComplete(comparisonResult)
    } catch (error) {
      console.error("Biometric verification failed:", error)
      const failedResult: BiometricResult = {
        isMatch: false,
        confidence: 0,
        livenessPassed: false,
        faceDetected: false,
        qualityScore: 0,
      }
      setVerificationResult(failedResult)
      setVerificationStep("complete")
      onVerificationComplete(failedResult)
    } finally {
      setIsVerifying(false)
    }
  }

  const resetVerification = () => {
    setLiveSelfie("")
    setVerificationStep("capture")
    setVerificationResult(null)
    setProcessingProgress(0)
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return "text-primary"
    if (confidence >= 0.6) return "text-yellow-600"
    return "text-destructive"
  }

  const getConfidenceText = (confidence: number) => {
    if (confidence >= 0.9) return "Very High"
    if (confidence >= 0.8) return "High"
    if (confidence >= 0.6) return "Medium"
    return "Low"
  }

  return (
    <div className="space-y-6">
      {/* Document Reference */}
      {documentImageUrl && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Document Photo Reference
            </CardTitle>
            <CardDescription>This is the photo from your document that will be compared</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="w-32 h-40 mx-auto">
              <img
                src={documentImageUrl || "/placeholder.svg"}
                alt="Document photo"
                className="w-full h-full object-cover rounded-lg border-2 border-border"
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Camera Capture */}
      {verificationStep === "capture" && <CameraCapture onCapture={handleSelfieCapture} isCapturing={isVerifying} />}

      {/* Processing */}
      {verificationStep === "processing" && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Loader2 className="h-5 w-5 animate-spin" />
              Verifying Identity
            </CardTitle>
            <CardDescription>Processing biometric data using AI</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Processing Progress</span>
                <span>{processingProgress}%</span>
              </div>
              <Progress value={processingProgress} className="w-full" />
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${processingProgress >= 20 ? "bg-primary" : "bg-muted"}`} />
                Face Detection
              </div>
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${processingProgress >= 40 ? "bg-primary" : "bg-muted"}`} />
                Liveness Verification
              </div>
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${processingProgress >= 60 ? "bg-primary" : "bg-muted"}`} />
                Face Comparison
              </div>
            </div>

            <Alert>
              <Shield className="h-4 w-4" />
              <AlertDescription>
                All biometric processing is happening locally on your device for maximum privacy.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      )}

      {/* Results */}
      {verificationStep === "complete" && verificationResult && (
        <Card
          className={
            verificationResult.isMatch ? "border-primary/20 bg-primary/5" : "border-destructive/20 bg-destructive/5"
          }
        >
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {verificationResult.isMatch ? (
                <CheckCircle className="h-5 w-5 text-primary" />
              ) : (
                <XCircle className="h-5 w-5 text-destructive" />
              )}
              Biometric Verification {verificationResult.isMatch ? "Passed" : "Failed"}
            </CardTitle>
            <CardDescription>
              {verificationResult.isMatch
                ? "Your identity has been successfully verified"
                : "Identity verification was unsuccessful"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-sm font-medium text-muted-foreground">Match Confidence</label>
                <div className="flex items-center gap-2">
                  <span className={`font-mono text-lg ${getConfidenceColor(verificationResult.confidence)}`}>
                    {Math.round(verificationResult.confidence * 100)}%
                  </span>
                  <Badge variant="outline" className={getConfidenceColor(verificationResult.confidence)}>
                    {getConfidenceText(verificationResult.confidence)}
                  </Badge>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-sm font-medium text-muted-foreground">Quality Score</label>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-lg">{Math.round(verificationResult.qualityScore * 100)}%</span>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-sm font-medium text-muted-foreground">Face Detected</label>
                <div className="flex items-center gap-2">
                  {verificationResult.faceDetected ? (
                    <CheckCircle className="h-4 w-4 text-primary" />
                  ) : (
                    <XCircle className="h-4 w-4 text-destructive" />
                  )}
                  <span className="text-sm">{verificationResult.faceDetected ? "Yes" : "No"}</span>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-sm font-medium text-muted-foreground">Liveness Check</label>
                <div className="flex items-center gap-2">
                  {verificationResult.livenessPassed ? (
                    <CheckCircle className="h-4 w-4 text-primary" />
                  ) : (
                    <XCircle className="h-4 w-4 text-destructive" />
                  )}
                  <span className="text-sm">{verificationResult.livenessPassed ? "Passed" : "Failed"}</span>
                </div>
              </div>
            </div>

            {!verificationResult.isMatch && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Verification failed. Please ensure good lighting, face the camera directly, and try again.
                </AlertDescription>
              </Alert>
            )}

            <div className="flex gap-2">
              <Button variant="outline" onClick={resetVerification} className="flex-1 bg-transparent">
                Try Again
              </Button>
              {verificationResult.isMatch && <Button className="flex-1">Continue to Final Verification</Button>}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Action Button */}
      {verificationStep === "capture" && liveSelfie && (
        <Button onClick={startVerification} disabled={isVerifying} className="w-full" size="lg">
          {isVerifying ? "Verifying..." : "Start Biometric Verification"}
        </Button>
      )}
    </div>
  )
}
