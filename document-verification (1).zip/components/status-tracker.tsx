"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  CheckCircle,
  Clock,
  Loader2,
  XCircle,
  Upload,
  FileText,
  QrCode,
  User,
  Shield,
  Hash,
  AlertCircle,
} from "lucide-react"
import type { VerificationSession, VerificationStep } from "@/lib/status-tracker"
import { getSessionProgress, getEstimatedTimeRemaining } from "@/lib/status-tracker"

interface StatusTrackerProps {
  session: VerificationSession
  onRefresh?: () => void
}

export function StatusTracker({ session, onRefresh }: StatusTrackerProps) {
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const getStepIcon = (step: VerificationStep) => {
    const iconClass = "h-5 w-5"

    switch (step.id) {
      case "upload":
        return <Upload className={iconClass} />
      case "consent":
        return <Shield className={iconClass} />
      case "ocr":
        return <FileText className={iconClass} />
      case "qr":
        return <QrCode className={iconClass} />
      case "biometric":
        return <User className={iconClass} />
      case "validation":
        return <CheckCircle className={iconClass} />
      case "hash":
        return <Hash className={iconClass} />
      default:
        return <Clock className={iconClass} />
    }
  }

  const getStepStatusIcon = (status: VerificationStep["status"]) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-primary" />
      case "in-progress":
        return <Loader2 className="h-4 w-4 text-primary animate-spin" />
      case "failed":
        return <XCircle className="h-4 w-4 text-destructive" />
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />
    }
  }

  const getStatusColor = (status: VerificationSession["overallStatus"]) => {
    switch (status) {
      case "completed":
        return "bg-primary text-primary-foreground"
      case "failed":
        return "bg-destructive text-destructive-foreground"
      case "processing":
      case "verifying":
        return "bg-secondary text-secondary-foreground"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  const progress = getSessionProgress(session)
  const timeElapsed = Math.floor((currentTime.getTime() - new Date(session.startTime).getTime()) / 1000)
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <div className="space-y-6">
      {/* Session Overview */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                Session: {session.sessionId}
                <Badge className={getStatusColor(session.overallStatus)}>
                  {session.overallStatus.charAt(0).toUpperCase() + session.overallStatus.slice(1)}
                </Badge>
              </CardTitle>
              <CardDescription>
                {session.documentType.toUpperCase()} verification • {session.fileName}
              </CardDescription>
            </div>
            {onRefresh && (
              <Button variant="outline" size="sm" onClick={onRefresh}>
                Refresh
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Overall Progress</span>
              <span>{progress}%</span>
            </div>
            <Progress value={progress} className="w-full" />
          </div>

          {/* Time Information */}
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Time Elapsed:</span>
              <p className="font-mono">{formatTime(timeElapsed)}</p>
            </div>
            <div>
              <span className="text-muted-foreground">Estimated Remaining:</span>
              <p className="font-mono">{getEstimatedTimeRemaining(session)}</p>
            </div>
          </div>

          {/* Current Status */}
          {session.overallStatus === "processing" && (
            <Alert>
              <Loader2 className="h-4 w-4 animate-spin" />
              <AlertDescription>
                Currently processing: {session.steps.find((s) => s.id === session.currentStep)?.name || "Unknown step"}
              </AlertDescription>
            </Alert>
          )}

          {session.overallStatus === "completed" && session.hashId && (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                Verification completed successfully! Hash ID: <code className="font-mono">{session.hashId}</code>
              </AlertDescription>
            </Alert>
          )}

          {session.overallStatus === "failed" && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Verification failed. Please check the details below and try again if needed.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Step-by-Step Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Verification Steps</CardTitle>
          <CardDescription>Detailed progress through each verification stage</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {session.steps.map((step, index) => (
              <div key={step.id} className="flex items-start gap-4">
                {/* Step Icon */}
                <div
                  className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                    step.status === "completed"
                      ? "bg-primary border-primary text-primary-foreground"
                      : step.status === "in-progress"
                        ? "bg-primary/10 border-primary text-primary"
                        : step.status === "failed"
                          ? "bg-destructive border-destructive text-destructive-foreground"
                          : "bg-muted border-muted-foreground text-muted-foreground"
                  }`}
                >
                  {getStepIcon(step)}
                </div>

                {/* Step Content */}
                <div className="flex-1 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium flex items-center gap-2">
                        {step.name}
                        {getStepStatusIcon(step.status)}
                      </h4>
                      <p className="text-sm text-muted-foreground">{step.description}</p>
                    </div>
                    {step.timestamp && (
                      <div className="text-xs text-muted-foreground text-right">
                        <p>{new Date(step.timestamp).toLocaleTimeString()}</p>
                        {step.duration && <p>{(step.duration / 1000).toFixed(1)}s</p>}
                      </div>
                    )}
                  </div>

                  {/* Step Details */}
                  {step.details && (
                    <div className="text-sm bg-muted p-2 rounded">
                      <p>{step.details}</p>
                    </div>
                  )}

                  {/* Confidence Score */}
                  {step.confidence && (
                    <div className="flex items-center gap-2 text-sm">
                      <span className="text-muted-foreground">Confidence:</span>
                      <Badge variant="outline">{Math.round(step.confidence * 100)}%</Badge>
                    </div>
                  )}

                  {/* Progress indicator for current step */}
                  {step.status === "in-progress" && (
                    <div className="space-y-1">
                      <Progress value={Math.random() * 100} className="w-full h-1" />
                      <p className="text-xs text-muted-foreground">Processing...</p>
                    </div>
                  )}
                </div>

                {/* Connection line to next step */}
                {index < session.steps.length - 1 && (
                  <div className="absolute left-[2.5rem] mt-10 w-0.5 h-6 bg-border" />
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Session Actions */}
      {session.overallStatus === "completed" && (
        <Card>
          <CardHeader>
            <CardTitle>Next Steps</CardTitle>
            <CardDescription>Your document has been successfully verified</CardDescription>
          </CardHeader>
          <CardContent className="flex gap-2">
            <Button className="flex-1">View Verification Certificate</Button>
            <Button variant="outline" className="flex-1 bg-transparent">
              Download Hash ID
            </Button>
          </CardContent>
        </Card>
      )}

      {session.overallStatus === "failed" && (
        <Card>
          <CardHeader>
            <CardTitle>Verification Failed</CardTitle>
            <CardDescription>There was an issue with your document verification</CardDescription>
          </CardHeader>
          <CardContent className="flex gap-2">
            <Button variant="outline" className="flex-1 bg-transparent">
              Try Again
            </Button>
            <Button variant="outline" className="flex-1 bg-transparent">
              Contact Support
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
