"use client"

import { useState, useRef, useCallback, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Camera, RotateCcw, CheckCircle, AlertCircle, Eye } from "lucide-react"

interface CameraCaptureProps {
  onCapture: (imageData: string) => void
  isCapturing?: boolean
}

export function CameraCapture({ onCapture, isCapturing = false }: CameraCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [isReady, setIsReady] = useState(false)
  const [error, setError] = useState<string>("")
  const [capturedImage, setCapturedImage] = useState<string>("")
  const [countdown, setCountdown] = useState<number>(0)

  const startCamera = useCallback(async () => {
    try {
      setError("")
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: "user",
        },
      })

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream
        setStream(mediaStream)
        setIsReady(true)
      }
    } catch (err) {
      setError("Camera access denied. Please allow camera permissions and try again.")
      console.error("Camera error:", err)
    }
  }, [])

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      setStream(null)
      setIsReady(false)
    }
  }, [stream])

  const capturePhoto = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return

    // Start countdown
    setCountdown(3)
    const countdownInterval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(countdownInterval)

          // Capture the photo
          const canvas = canvasRef.current!
          const video = videoRef.current!
          const context = canvas.getContext("2d")!

          canvas.width = video.videoWidth
          canvas.height = video.videoHeight
          context.drawImage(video, 0, 0)

          const imageData = canvas.toDataURL("image/jpeg", 0.8)
          setCapturedImage(imageData)
          onCapture(imageData)

          return 0
        }
        return prev - 1
      })
    }, 1000)
  }, [onCapture])

  const retakePhoto = useCallback(() => {
    setCapturedImage("")
    setCountdown(0)
  }, [])

  useEffect(() => {
    return () => {
      stopCamera()
    }
  }, [stopCamera])

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Camera className="h-5 w-5" />
          Live Selfie Capture
        </CardTitle>
        <CardDescription>Take a live selfie to verify your identity against the document photo</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="relative">
          {!isReady && !capturedImage && (
            <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
              <div className="text-center space-y-4">
                <Camera className="h-16 w-16 text-muted-foreground mx-auto" />
                <div>
                  <p className="font-medium">Camera Not Started</p>
                  <p className="text-sm text-muted-foreground">Click start to begin selfie capture</p>
                </div>
                <Button onClick={startCamera}>Start Camera</Button>
              </div>
            </div>
          )}

          {isReady && !capturedImage && (
            <div className="relative">
              <video ref={videoRef} autoPlay playsInline muted className="w-full aspect-video rounded-lg bg-black" />

              {/* Face detection overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-48 h-60 border-2 border-primary rounded-full opacity-50"></div>
              </div>

              {/* Countdown overlay */}
              {countdown > 0 && (
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                  <div className="text-6xl font-bold text-white">{countdown}</div>
                </div>
              )}

              {/* Instructions */}
              <div className="absolute bottom-4 left-4 right-4">
                <Alert>
                  <Eye className="h-4 w-4" />
                  <AlertDescription>
                    Position your face within the oval and look directly at the camera
                  </AlertDescription>
                </Alert>
              </div>
            </div>
          )}

          {capturedImage && (
            <div className="relative">
              <img
                src={capturedImage || "/placeholder.svg"}
                alt="Captured selfie"
                className="w-full aspect-video rounded-lg object-cover"
              />
              <div className="absolute top-4 right-4">
                <Badge className="bg-primary text-primary-foreground">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Captured
                </Badge>
              </div>
            </div>
          )}

          <canvas ref={canvasRef} className="hidden" />
        </div>

        <div className="flex gap-2">
          {isReady && !capturedImage && (
            <>
              <Button onClick={capturePhoto} disabled={isCapturing || countdown > 0} className="flex-1">
                {countdown > 0 ? `Capturing in ${countdown}...` : "Capture Selfie"}
              </Button>
              <Button variant="outline" onClick={stopCamera}>
                Stop Camera
              </Button>
            </>
          )}

          {capturedImage && (
            <>
              <Button variant="outline" onClick={retakePhoto} className="flex-1 bg-transparent">
                <RotateCcw className="h-4 w-4 mr-2" />
                Retake Photo
              </Button>
              {!isReady && <Button onClick={startCamera}>Start Camera</Button>}
            </>
          )}
        </div>

        {/* Privacy notice */}
        <Alert>
          <AlertDescription className="text-xs">
            Your selfie is processed locally and not stored or transmitted to any servers.
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  )
}
